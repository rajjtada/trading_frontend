let apiBaseUrl = ""

export default apiBaseUrl;